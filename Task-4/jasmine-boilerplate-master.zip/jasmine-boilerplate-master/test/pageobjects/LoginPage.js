import Page from './page'

class LoginPage extends Page {
    /**
     * define elements
     */
    get inputEmail () { return $('input[type="email"]') }
    get inputPassword () { return $('input[type="password"]')}
    get buttonEmailNext () { return $('div[id="identifierNext"]') }
    get buttonPasswordNext () { return $('div[id="passwordNext"]') }
    get headingText () { return $('h1[id="headingText"]') }
    /**
     * define or overwrite page methods
     */
    open () {
        browser.url('/')
    }

    clickEmailNext () {
        this.buttonEmailNext.click()
    }

    clickPasswordNext () {
        this.buttonPasswordNext.click()
    }
}

export default new LoginPage()

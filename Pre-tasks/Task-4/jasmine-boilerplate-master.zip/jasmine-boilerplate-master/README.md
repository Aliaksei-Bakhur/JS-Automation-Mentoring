## How to install and execute test

1. Run 'npm install' to get modules installed.

2. Run 'npm test' to start executing test.
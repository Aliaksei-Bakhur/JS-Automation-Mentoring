import LoginPage from '../pageobjects/LoginPage';

var user1 = { email: 'js.task.alexb1@gmail.com', password: 'js1234js'},
    user2 = { email: 'js.task.alexb2@gmail.com', password: 'js1234js'},
    subjectTitle = 'AutoSubject ' + +new Date(),
    iconUser1 = 'a[title*="' + user1.email + '"]',
    buttonCompose = '//div[text()="COMPOSE"]',
    inputTo = 'textarea[aria-label="To"]',
    inputSubjectBox = 'input[name="subjectbox"]',
    inputMessage = 'div[aria-label="Message Body"]',
    textMessage = 'AutoTest Message Body',
    buttonSend = '//div[text()="Send"]',
    messageOnSend = '//div[contains(text(),"Your message has been sent")]',
    linkSentMail = 'a[title="Sent Mail"]',
    sentEmailTitle = '//span[text()="' + subjectTitle + '"]',
    linkLogout = '[aria-label="Account Information"] a[href*="Logout"]',
    iconSwitchAccount = '[aria-label="Switch account"]',
    buttonUseAnotherAccount = '#identifierLink',
    inputEmail = 'input[type="email"]',
    iconUser2 = 'a[title*="' + user2.email + '"]',
    inboxEmailTitle = '//span/b[contains(text(),"' + subjectTitle + '")]',
    inboxEmailDetails = '//h2[text()="' + subjectTitle + '"]',
    emailSender = '[jid="' + user1.email + '"]'

        /*1.Login into account
        2.Send email to account
        3.Check presence of e-mail in Sent folder
        4.Login into account
        5.Check presence of email sent from account*/

describe('Login to gmail account and send the email', function () {
    it('Login to gmail an account', function () {
        LoginPage.open()
        LoginPage.inputEmail.setValue(user1.email)
        LoginPage.clickEmailNext()
        browser.waitUntil(function () {
            return LoginPage.headingText.getText() === 'Welcome'
            }, 5000, 'Expected navigation to Welcome page in 5 seconds')
        LoginPage.inputPassword.setValue(user1.password)
        LoginPage.clickPasswordNext(buttonSend)
      //  browser.waitForVisible(iconUser1)
        expect(browser.waitForVisible(iconUser1)).toEqual(true)
    //    })

    //it('Send email to another account', function () {
        browser.click(buttonCompose)
        browser.waitForVisible(inputTo)
        browser.setValue(inputTo, user2.email)
        browser.setValue(inputSubjectBox, subjectTitle)
        browser.setValue(inputMessage, textMessage)
        browser.click(buttonSend)
        expect(browser.waitForVisible(messageOnSend)).toEqual(true)
    //    })
    
    //it('Check presence of e-mail in Sent folder', function () {
        browser.waitForVisible(linkSentMail)   
        browser.click(linkSentMail)
        expect(browser.waitForVisible(sentEmailTitle)).toEqual(true)
    //    })

    //it('Login into another account', function () {
       // browser.waitForVisible('a[title*="' + user1.email + '"]')
       // browser.click('a[title*="' + user1.email + '"]')
        browser.url(browser.getAttribute(linkLogout, 'href'))
       // browser.waitForVisible('[aria-label="Account Information"] a[href*="Logout"]')
       // browser.click('[aria-label="Account Information"] a[href*="Logout"]')
        browser.click(iconSwitchAccount)
        browser.waitForVisible(buttonUseAnotherAccount)
        browser.click(buttonUseAnotherAccount)
        browser.waitForVisible(inputEmail)
        LoginPage.inputEmail.setValue(user2.email)
        LoginPage.clickEmailNext()
        browser.waitUntil(function () {
            return LoginPage.headingText.getText() === 'Welcome'
            }, 5000, 'Expected navigation to Welcome page in 5 seconds')
        LoginPage.inputPassword.setValue(user2.password)
        LoginPage.clickPasswordNext()
        expect(browser.waitForVisible(iconUser2)).toEqual(true)
    //    })

    //it('Check presence of email sent from account', function () {
        browser.waitForVisible(inboxEmailTitle)
        browser.click(inboxEmailTitle)
        browser.waitForVisible(inboxEmailDetails)
        expect(browser.isExisting(emailSender)).toEqual(true)
    })
})